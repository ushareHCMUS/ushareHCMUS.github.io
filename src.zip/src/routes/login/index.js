import PageLogin from './components/Login';

export default PageLogin;