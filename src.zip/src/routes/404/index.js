import Page404 from './components/404';

export default Page404;