import PageRooms from './components/Rooms';

export default PageRooms;