import NewsPage from './components/News';

export default NewsPage;