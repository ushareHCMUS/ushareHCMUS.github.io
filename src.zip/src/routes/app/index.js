import MainApp from './components/MainApp';

export default MainApp;